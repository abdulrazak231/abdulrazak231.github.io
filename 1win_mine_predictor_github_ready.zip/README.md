
# 1Win Mine Predictor - Dark Theme

This is a dark-themed 1Win Mine Predictor simulation tool built using HTML, CSS, and JavaScript.

## Features
- Manual tile clicking (safe or mine)
- Random mine generation
- Predict next safe tile
- Cash out simulation
- Multiplier logic similar to 1Win

## How to Deploy on GitHub Pages

1. Create a repository named `yourusername.github.io`
2. Upload the `index.html` file to the root of the repo
3. Go to **Settings > Pages**, and choose branch = `main`, folder = `/ (root)`
4. Visit https://yourusername.github.io to access the live tool

Enjoy!
